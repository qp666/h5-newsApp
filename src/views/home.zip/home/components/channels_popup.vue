<template>
  <van-popup
    class="cha_pop"
    closeable
    close-icon="close"
    close-icon-position="top-left"
    v-model="show"
    position="left"
    :style="{ height: '100%', width: '85%' }"
  >
    <!-- 上面内容 -->
    <div class="top_pop">
      <div class="top_pop_one">
        <span>我的频道</span>
        <van-button round color="#f85a5a" size="mini" plain>编辑</van-button>
      </div>
      <span class="ttag" v-for="(item, index) in myList" :key="index">
        <van-tag v-if="index != 0" size="large">{{ item.name }}</van-tag>
      </span>
    </div>

    <!-- 下面内容 -->
    <div class="bottom_pop">
      <div class="top_pop_one">
        <span>频道推荐</span>
      </div>
      <van-tag
        @click="getmyList(item)"
        v-for="(item, index) in noAllList"
        :key="index"
        size="large"
      >
        + {{ item.name }}</van-tag
      >
    </div>
  </van-popup>
</template>

<script>
import { get_allChannels, get_user_Channels } from "@/api/channels.js";
export default {
  name: "channels_popup",

  props: { topp: {} },
  //数据
  data() {
    return {
      show: false,
      myList: this.topp,
      noAllList: []
    };
  },
  //方法
  methods: {
    //把全部频道的数据点击的频道增加到我的频道
    getmyList(item) { 
      //显示到我的频道
      this.myList.push(item);
      //从全部频道中删除已经添加到我的频道的数据
      this.noAllList.forEach(im => {
        if (im == item) {
          this.noAllList.splice(im, 1);
        }
        // return;
      });
      //创建一个数组channels 等于 我的频道的数据去掉第一个(推荐)通过map方法返回的数组
      let channels = this.myList.slice(1).map((itm, index) => {
        let obj = {
          id: itm.id,
          seq: index + 1
        };
        return obj;
      });

      //调用接口把channels数组作为对象传进去
      get_user_Channels({ channels });
    }
  },
  //计算属性
  computed: {
    //
    // cmAllList(){

    // }
  },
  //过滤器
  filters: {},
  //进入页面就执行的生命周期,不能访问dom,可以访问data与methods
  async created() {
    //!过滤包含已有频道
    let res = await get_allChannels();
    console.log("所有频道数据", res);
    //!1.获取所有频道
    let allList = res.data.channels;

    //!2.利用数组的map方法把已有频道的id返回出来成一个数组 list1
    let list1 = this.myList.map(item => {
      return item.id;
    });

    //!3.利用数组的filter方法把所有频道的数组遍历 判断如果数组对象里面id跟 数组list1id不一样的就返回出来成为一个新数组,新数组就是把已有频道刨除后的数组
    this.noAllList = allList.filter(item => {
      return !list1.includes(item.id);
    });

    console.log("过滤后的所有频道:", this.noAllList);
  },
  //渲染页面后执行的生命周期,可以访问dom
  mounted() {},
  //侦听器
  watch: {
    topp(val) {
      this.myList = val;
    }
  },
  //子页面
  components: {}
};
</script>

<style lang="less">
.cha_pop {
  padding: 10px;
  i.van-icon.van-icon-close.van-popup__close-icon.van-popup__close-icon--top-left {
    color: black;
    font-size: 25px;
  }

  .top_pop {
    margin-top: 50px;
    margin-bottom: 30px;
  }
  .top_pop_one {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
    //   padding: 10px;
  }

  span.van-tag.van-tag--large.van-tag--default {
    margin-right: 10px;
    margin-bottom: 10px;
  }
}
</style>
